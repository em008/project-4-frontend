<template>
  <div class="home">
    <!-- <b-image
      src="https://cdn.pixabay.com/photo/2018/05/08/08/44/artificial-intelligence-3382507_1280.jpg"
      ratio="16by9"
      responsive="true"
    ></b-image> -->
  </div>
</template>

<script>
export default {
  name: "Home",
  components: {}
};
</script>

<style>
</style>

