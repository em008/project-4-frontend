<template>
  <div class="sticky">
    <footer class="footer content has-text-centered">© 2020 StudyDB. All Rights Reserved.</footer>
  </div>
</template>

<script>
export default {
  name: "footer"
};
</script>


<style>
div.sticky {
  position: -webkit-sticky;
  position: sticky;
  bottom: 0;
  /* width: 100%; */
  /* overflow: hidden; */
}
</style>
